﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    public class Base64StringManipulator : : IstringManipulator
    {
        public string Manipulate(string plainText) {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }
    }
}
