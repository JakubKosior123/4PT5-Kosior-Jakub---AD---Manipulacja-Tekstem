﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
   public class SuffixStringManipulator : : IstringManipulator
    {
        public string Manipulate(string input)
        {
            return input + "_123";
        }
    }
}
