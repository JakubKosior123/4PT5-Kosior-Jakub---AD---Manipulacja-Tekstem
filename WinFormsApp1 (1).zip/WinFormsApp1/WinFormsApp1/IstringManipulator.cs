﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    interface IstringManipulator
    {
        public string Manipulate(string input);
    }
}
