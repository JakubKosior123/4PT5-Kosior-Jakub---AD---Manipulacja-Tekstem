﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WinFormsApp1
{
    public class ReverseStringManipulator : : IstringManipulator
    {
        public string Manipulate()
        {
            string myString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            char[] charArray = myString.ToCharArray();

            Array.Reverse(charArray);

            string newString = "";

            foreach (char tempChar in charArray)
            {
                newString += tempChar;
            }
            return newString;
        }
    }
}
