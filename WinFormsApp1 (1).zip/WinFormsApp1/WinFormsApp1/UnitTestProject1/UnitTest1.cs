namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSuffixes()
        {
            var manipulator = new WinFormsApp1.SuffixStringManipulator();

            Assert.AreEqual("test_123", manipulator.Manipulate("test"));
            Assert.AreEqual("abc_123", manipulator.Manipulate("abc"));
            Assert.AreEqual("_123", manipulator.Manipulate(""));
        }

        public void TestReverses()
        {
            var manipulator = new WinFormsApp1.ReverseStringManipulator();

            Assert.AreEqual("tset", manipulator.Manipulate("test"));
            Assert.AreEqual("cba", manipulator.Manipulate("abc"));
            Assert.AreEqual("elpmaxe", manipulator.Manipulate("example"));
        }

        public void TestBase64()
        {
            var manipulator = new WinFormsApp1.Base64StringManipulator();

            Assert.AreEqual("dGVzdA==", manipulator.Manipulate("test"));
            Assert.AreEqual("YWJj", manipulator.Manipulate("abc"));
            Assert.AreEqual("ZXhhbXBsZQ==", manipulator.Manipulate("example"));
        }
    }
}